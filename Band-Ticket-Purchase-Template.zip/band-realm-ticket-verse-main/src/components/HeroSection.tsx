
import { Button } from "@/components/ui/button";

export const HeroSection = () => {
  const handleGetTickets = () => {
    // In a real app, this would redirect to a ticket purchasing platform
    window.open('https://ticketmaster.com', '_blank');
  };

  return (
    <section className="relative h-screen bg-gradient-to-r from-black to-gray-900 flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 bg-black/50 z-10"></div>
      <div className="absolute inset-0">
        <div className="w-full h-full bg-gradient-to-b from-transparent via-red-900/20 to-black"></div>
      </div>
      
      <div className="relative z-20 text-center">
        {/* BRCM Logo */}
        <div className="mb-8">
          <div className="relative inline-block">
            <div className="grid grid-cols-2 gap-4 text-6xl md:text-8xl font-black">
              <div className="text-white">B</div>
              <div className="text-white">R</div>
              <div className="text-white">C</div>
              <div className="text-white">M</div>
            </div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-32 h-32 md:w-48 md:h-48 border-4 border-white rotate-45"></div>
              <div className="absolute w-16 h-1 bg-white"></div>
              <div className="absolute w-1 h-16 bg-white"></div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <h1 className="text-2xl md:text-4xl font-bold tracking-wider">
            ON TOUR <span className="text-red-600">NOW</span>
          </h1>
          <Button 
            onClick={handleGetTickets}
            className="bg-transparent border-2 border-white text-white hover:bg-white hover:text-black transition-all duration-300 px-8 py-3 rounded-full font-bold tracking-wider"
          >
            GET TICKETS
          </Button>
        </div>
      </div>

      {/* Band silhouettes */}
      <div className="absolute right-0 top-0 w-1/2 h-full opacity-60">
        <div className="w-full h-full bg-gradient-to-l from-gray-600/30 to-transparent"></div>
      </div>
    </section>
  );
};


import { Button } from "@/components/ui/button";

export const EventsSection = () => {
  const events = [
    {
      date: "MAR 20 2024",
      location: "BUENOS AIRES, ARGENTINA",
      venue: "NICETO CLUB"
    },
    {
      date: "MAR 25 2024",
      location: "SANTIAGO, CHILE",
      venue: "BLONDIE"
    },
    {
      date: "MAR 28 2024",
      location: "SAN BERNARDINO, CA",
      venue: "LOST HIGHWAY 2024"
    }
  ];

  const handleBuyTickets = (event: string) => {
    // In a real app, this would redirect to specific event tickets
    window.open(`https://ticketmaster.com/search?q=BRCM+${event}`, '_blank');
  };

  return (
    <section className="py-16 bg-gradient-to-r from-red-600 to-red-700">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          <div className="text-white space-y-8">
            <h2 className="text-4xl font-bold">
              UPCOMING<br />EVENTS
            </h2>
            
            <div className="space-y-6">
              {events.map((event, index) => (
                <div key={index} className="border-b border-white/20 pb-4">
                  <div className="text-sm opacity-80 mb-1">{event.date}</div>
                  <div className="font-bold text-lg mb-1">{event.location}</div>
                  <div className="text-sm opacity-80 mb-3">{event.venue}</div>
                  <Button 
                    onClick={() => handleBuyTickets(event.location)}
                    className="bg-white text-red-600 hover:bg-gray-200 transition-all duration-300 px-6 py-2 rounded-full font-bold text-sm"
                  >
                    BUY TICKETS
                  </Button>
                </div>
              ))}
            </div>
          </div>
          
          <div className="relative">
            <div className="w-full h-96 bg-black/30 rounded-lg overflow-hidden">
              <div className="w-full h-full bg-gradient-to-br from-black/50 to-transparent flex items-center justify-center">
                <div className="text-center text-white">
                  <div className="text-6xl mb-4">🎤</div>
                  <p className="text-lg">Live Performance</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

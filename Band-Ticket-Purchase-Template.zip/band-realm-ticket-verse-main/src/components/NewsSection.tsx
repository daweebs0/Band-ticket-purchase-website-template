
import { Button } from "@/components/ui/button";

export const NewsSection = () => {
  return (
    <section className="py-16 bg-gradient-to-r from-red-600 to-red-700">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          <div className="relative">
            <div className="w-full h-96 bg-black/30 rounded-lg overflow-hidden">
              <div className="w-full h-full bg-gradient-to-br from-black/50 to-transparent flex items-center justify-center">
                <div className="text-center text-white">
                  <div className="text-6xl mb-4">🎸</div>
                  <p className="text-lg">Latest Performance</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="text-white space-y-6">
            <div>
              <h2 className="text-4xl font-bold mb-2">NEWS</h2>
              <p className="text-xl opacity-80">19.03.2024</p>
            </div>
            
            <div className="space-y-4 text-lg">
              <p>Hey guys! Great news for all our fans!</p>
              <p>We have 3 new events scheduled and going on tour!</p>
              <p>Check out our "Events" section for more information.</p>
              <p>New album is currently being produced and looking forward to meet y'all really soon.</p>
              <p>Check our Instagram for our travel photos and new crazy hats guys have brought!</p>
            </div>
            
            <Button className="bg-transparent border-2 border-white text-white hover:bg-white hover:text-red-600 transition-all duration-300 px-8 py-3 rounded-full font-bold">
              VIEW ALL
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

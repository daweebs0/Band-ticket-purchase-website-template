
import { Button } from "@/components/ui/button";

export const AboutSection = () => {
  return (
    <section className="py-16 bg-black">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          <div className="relative">
            <div className="w-full h-96 bg-gray-800 rounded-lg overflow-hidden">
              <div className="w-full h-full bg-gradient-to-br from-gray-700 to-gray-900 flex items-center justify-center">
                <div className="text-center text-white">
                  <div className="text-6xl mb-4">🥁</div>
                  <p className="text-lg">Studio Session</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="text-white space-y-6">
            <h2 className="text-4xl font-bold">ABOUT THE BAND</h2>
            
            <div className="space-y-4 text-lg text-gray-300 leading-relaxed">
              <p>
                The band was formed in 1998, originally called The Element. After 
                discovering that another band had the same name, the members 
                changed the name to Black Rebel Motorcycle Club, after Marlon 
                Brando's motorcycle gang in the 1953 film The Wild One.
              </p>
              <p>
                Bassist Robert Levon Been and guitarist Peter Hayes met...
              </p>
            </div>
            
            <Button className="bg-red-600 hover:bg-red-700 text-white transition-all duration-300 px-8 py-3 rounded-full font-bold">
              CONTINUE READING
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

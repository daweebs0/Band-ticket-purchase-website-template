
export const AlbumsSection = () => {
  const albums = [
    {
      year: "2001",
      title: "DEVILS AND TEARS",
      tracks: ["WHITE PALMS", "HE SUN", "RIFLES", "READ YOUR LOVE", "SALVATION"]
    },
    {
      year: "2007",
      title: "BABY 81",
      tracks: ["TOOK OUT A LOAN", "BERLIN", "WEAPON OF CHOICE", "WINDOWS", "COLD WIND", "NOT WHAT YOU WANTED", "666 CONDUCER", "ALL YOU DO IS TALK", "LIEN ON YOUR DREAMS", "SOME AIN'T", "KILLING THE LIGHT", "AMERICAN X", "AM I ONLY"]
    },
    {
      year: "2010",
      title: "BEAT THE DEVIL'S",
      tracks: ["CONSCIENCE KILLER", "WAR MACHINE", "SW", "EVOL", "MAMA SAID", "RIVER STX", "TH", "LONG WAY DOWN", "TST", "MAR"]
    }
  ];

  return (
    <section className="py-16 bg-black">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {albums.map((album, index) => (
            <div key={index} className="text-center">
              <div className="mb-6">
                <div className="text-gray-500 text-2xl font-bold mb-2">{album.year}</div>
                <h3 className="text-white text-xl font-bold mb-4">{album.title}</h3>
                <div className="w-full h-64 bg-gray-800 rounded-lg mb-4 flex items-center justify-center">
                  <div className="text-6xl text-gray-600">♪</div>
                </div>
              </div>
              
              <div className="space-y-2">
                {album.tracks.map((track, trackIndex) => (
                  <div key={trackIndex} className="text-gray-400 text-sm">
                    • {track}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

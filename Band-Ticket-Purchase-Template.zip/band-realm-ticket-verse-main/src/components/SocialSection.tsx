
import { Instagram, Youtube, Facebook } from "lucide-react";

export const SocialSection = () => {
  const socialLinks = [
    { icon: Instagram, url: "https://instagram.com/brcm", label: "Instagram" },
    { icon: Youtube, url: "https://youtube.com/brcm", label: "YouTube" },
    { icon: Facebook, url: "https://facebook.com/brcm", label: "Facebook" }
  ];

  return (
    <section className="py-16 bg-red-600">
      <div className="container mx-auto px-6">
        <div className="text-center">
          <h2 className="text-4xl font-bold text-white mb-8">SOCIAL MEDIA:</h2>
          
          <div className="flex justify-center space-x-8">
            {socialLinks.map((social, index) => (
              <a
                key={index}
                href={social.url}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-white hover:bg-gray-200 transition-all duration-300 p-4 rounded-lg group"
                aria-label={social.label}
              >
                <social.icon className="w-8 h-8 text-red-600 group-hover:scale-110 transition-transform duration-300" />
              </a>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

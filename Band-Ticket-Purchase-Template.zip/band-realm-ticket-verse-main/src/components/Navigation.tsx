
import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ChevronDown } from "lucide-react";

interface NavItem {
  id: string;
  label: string;
  dropdownItems: { label: string; href: string }[];
}

const navItemsData: NavItem[] = [
  {
    id: "news",
    label: "NEWS",
    dropdownItems: [
      { label: "Latest News", href: "#news-latest" },
      { label: "Announcements", href: "#news-announcements" },
      { label: "Interviews", href: "#news-interviews" },
    ],
  },
  {
    id: "music",
    label: "MUSIC",
    dropdownItems: [
      { label: "Albums", href: "#music-albums" },
      { label: "Singles", href: "#music-singles" },
      { label: "Lyrics", href: "#music-lyrics" },
      { label: "Streaming", href: "#music-streaming" },
    ],
  },
  {
    id: "events",
    label: "EVENTS",
    dropdownItems: [
      { label: "Upcoming Shows", href: "#events-upcoming" },
      { label: "Past Tours", href: "#events-past" },
      { label: "Ticket Information", href: "#events-tickets" },
    ],
  },
  {
    id: "about",
    label: "ABOUT",
    dropdownItems: [
      { label: "Band Biography", href: "#about-bio" },
      { label: "Meet The Band", href: "#about-members" },
      { label: "Our Journey", href: "#about-history" },
    ],
  },
  {
    id: "media",
    label: "MEDIA",
    dropdownItems: [
      { label: "Concert Photos", href: "#media-photos" },
      { label: "Music Videos", href: "#media-videos" },
      { label: "Fan Gallery", href: "#media-fan-gallery" },
    ],
  },
];

export const Navigation = () => {
  const [activeSection, setActiveSection] = useState("NEWS");

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-black/90 backdrop-blur-sm border-b border-red-600/20">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-8">
            {navItemsData.map((navItem) => (
              <DropdownMenu key={navItem.id}>
                <DropdownMenuTrigger asChild>
                  <button
                    onClick={() => setActiveSection(navItem.label)}
                    className={`flex items-center text-sm font-bold tracking-wider transition-colors ${
                      activeSection === navItem.label
                        ? "text-red-600 border-b-2 border-red-600 pb-1"
                        : "text-white hover:text-red-400"
                    }`}
                  >
                    {navItem.label}
                    <ChevronDown
                      className={`ml-1 h-4 w-4 transition-transform duration-200 ${
                        activeSection === navItem.label ? "text-red-600" : "text-white group-hover:text-red-400"
                      }`}
                    />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent 
                  className="bg-black border-red-600/50 text-white w-56"
                  // Assuming popover variables are set for dark theme by shadcn/ui
                  // If not, the classes above will provide a fallback styling
                >
                  {navItem.dropdownItems.map((item) => (
                    <DropdownMenuItem
                      key={item.label}
                      asChild
                      className="cursor-pointer hover:!bg-red-600/30 focus:!bg-red-700 hover:!text-white focus:!text-white"
                      // Using !important for hover/focus background and text if shadcn/ui accent colors don't fit
                    >
                      <a href={item.href} className="block w-full px-2 py-1.5 text-sm">
                        {item.label}
                      </a>
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            ))}
          </div>
          <Button className="bg-white text-black hover:bg-gray-200 font-bold px-6 py-2 rounded-full">
            STORE
          </Button>
        </div>
      </div>
    </nav>
  );
};


import { Navigation } from "@/components/Navigation";
import { HeroSection } from "@/components/HeroSection";
import { NewsSection } from "@/components/NewsSection";
import { AlbumsSection } from "@/components/AlbumsSection";
import { EventsSection } from "@/components/EventsSection";
import { AboutSection } from "@/components/AboutSection";
import { SocialSection } from "@/components/SocialSection";

const Index = () => {
  return (
    <div className="min-h-screen bg-black text-white">
      <Navigation />
      <HeroSection />
      <NewsSection />
      <AlbumsSection />
      <EventsSection />
      <AboutSection />
      <SocialSection />
    </div>
  );
};

export default Index;
